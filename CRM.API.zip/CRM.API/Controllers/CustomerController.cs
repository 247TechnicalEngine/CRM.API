using CRM.Service;
using MediatR;
using Microsoft.AspNetCore.Mvc;

namespace CRM.API.Controllers
{
    [ApiController]
    [Route("api/customers")]
    public class CustomerController : ControllerBase
    {
        private readonly IMediator _mediator;
        public CustomerController(IMediator mediator) => _mediator = mediator;

        [HttpPost]
        public async Task<IActionResult> Register([FromBody] RegisterCustomerCommand command)
        {
            var id = await _mediator.Send(command);
            return CreatedAtAction(nameof(Get), new { id }, new { id });
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> Get(string id)
        {
            var customer = await _mediator.Send(new GetCustomerQuery(id));
            return customer is not null ? Ok(customer) : NotFound();
        }

        [HttpPost("{customerId}/pricing")]
        public async Task<IActionResult> AddPricing(string customerId, [FromBody] AddPricingAgreementCommand command)
        {
            await _mediator.Send(new AddPricingAgreementCommand(customerId, command.ProductId, command.Price));
            return NoContent();
        }
    }
}
