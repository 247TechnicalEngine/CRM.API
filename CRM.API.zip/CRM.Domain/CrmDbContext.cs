﻿using CRM.Domain.Data;
using Microsoft.EntityFrameworkCore;

namespace CRM.Domain
{
    public class CrmDbContext : DbContext
    {
        public CrmDbContext(DbContextOptions<CrmDbContext> options) : base(options) { }

        public DbSet<Customer> Customers { get; set; }

        public DbSet<PricingAgreement> PricingAgreements { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
        }

    }
}
