﻿using System.ComponentModel.DataAnnotations;

namespace CRM.Domain.Data
{
    public class Customer
    {
        [Key]
        public string Id { get; set; }

        public string Name { get; set; }

        public string Email { get; set; }

        public string Status { get; set; }

        public List<PricingAgreement> PricingAgreements { get; set; } = new();
    }
}
