﻿using System.ComponentModel.DataAnnotations;

namespace CRM.Domain.Data
{
    public class PricingAgreement
    {
        [Key]
        public string ProductId { get; set; }

        public decimal AgreedPrice { get; set; }

        public DateTime EffectiveDate { get; set; }
    }
}
