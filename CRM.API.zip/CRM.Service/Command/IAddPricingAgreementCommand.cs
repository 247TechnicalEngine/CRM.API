﻿using MediatR;

namespace CRM.Service.Command
{
    public interface IAddPricingAgreementCommand : IRequest
    {
        string CustomerId { get; }

        string ProductId { get; }

        decimal Price { get; }
    }
}
