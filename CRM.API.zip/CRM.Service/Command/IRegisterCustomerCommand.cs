﻿using MediatR;

namespace CRM.Service.Command
{
    public interface IRegisterCustomerCommand : IRequest<string>
    {
        string Name { get; }
        string Email { get; }
    }
}
