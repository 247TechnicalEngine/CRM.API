﻿using CRM.Service.Command;

namespace CRM.Service
{
    public record RegisterCustomerCommand(string Name, string Email) : IRegisterCustomerCommand;

    public record AddPricingAgreementCommand(string CustomerId, string ProductId, decimal Price) : IAddPricingAgreementCommand;
}
