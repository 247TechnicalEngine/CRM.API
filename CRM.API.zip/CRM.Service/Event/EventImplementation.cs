﻿namespace CRM.Service.Event
{
    public record CustomerRegisteredEvent(string Id, string Name, string Email) : ICustomerRegisteredEvent;

    public record PricingAgreementAddedEvent(string CustomerId, string ProductId, decimal Price) : IPricingAgreementAddedEvent;
}
