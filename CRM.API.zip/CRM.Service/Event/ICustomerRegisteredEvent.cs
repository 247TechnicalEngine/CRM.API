﻿namespace CRM.Service.Event
{
    public interface ICustomerRegisteredEvent
    {
        string Id { get; }

        string Name { get; }

        string Email { get; }
    }
}
