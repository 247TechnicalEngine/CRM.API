﻿namespace CRM.Service.Event
{
    public interface IPricingAgreementAddedEvent
    {
        string CustomerId { get; }

        string ProductId { get; }

        decimal Price { get; }
    }
}
