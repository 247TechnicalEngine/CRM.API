﻿using Amazon.SQS.Model;
using Amazon.SQS;
using CRM.Domain.Data;
using CRM.Domain;
using CRM.Service.Command;
using CRM.Service.Event;
using MediatR;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;

namespace CRM.Service.Handler
{
    public class AddPricingAgreementHandler : IRequestHandler<IAddPricingAgreementCommand>
    {
        private readonly CrmDbContext _db;
        private readonly IAmazonSQS _sqs;
        private readonly string _queueUrl;

        public AddPricingAgreementHandler(CrmDbContext db, IAmazonSQS sqs, IConfiguration configuration)
        {
            _db = db;
            _sqs = sqs;
            _queueUrl = configuration["SQS:QueueUrl"];
        }


        /// <summary>
        /// the logic will send message to PIP service to add pricing agreement
        /// </summary>
        /// <param name="request"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public async Task Handle(IAddPricingAgreementCommand request, CancellationToken cancellationToken)
        {
            var customer = await _db.Customers.FindAsync(new object[] { request.CustomerId }, cancellationToken);
            if (customer == null) throw new Exception("Customer not found");

            customer.PricingAgreements.Add(new PricingAgreement { ProductId = request.ProductId, AgreedPrice = request.Price, EffectiveDate = DateTime.UtcNow });
            await _db.SaveChangesAsync(cancellationToken);

            var message = JsonConvert.SerializeObject(new PricingAgreementAddedEvent(request.CustomerId, request.ProductId, request.Price));
            await _sqs.SendMessageAsync(new SendMessageRequest
            {
                QueueUrl = _queueUrl,
                MessageBody = message
            }, cancellationToken);
        }
    }
}
