﻿using CRM.Domain.Data;
using CRM.Domain;
using CRM.Service.Query;
using MediatR;

namespace CRM.Service.Handler
{
    public class GetCustomerHandler : IRequestHandler<IGetCustomerQuery, Customer>
    {
        private readonly CrmDbContext _db;
        public GetCustomerHandler(CrmDbContext db) => _db = db;

        public async Task<Customer> Handle(IGetCustomerQuery request, CancellationToken cancellationToken)
        {
            return await _db.Customers.FindAsync(new object[] { request.Id }, cancellationToken);
        }
    }
}
