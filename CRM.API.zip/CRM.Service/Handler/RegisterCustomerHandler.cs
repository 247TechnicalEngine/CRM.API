﻿using CRM.Domain.Data;
using CRM.Domain;
using CRM.Service.Command;
using CRM.Service.Event;
using MediatR;
using Amazon.SQS;
using Microsoft.Extensions.Configuration;
using Amazon.SQS.Model;
using Newtonsoft.Json;

namespace CRM.Service.Handler
{
    public class RegisterCustomerHandler : IRequestHandler<IRegisterCustomerCommand, string>
    {
        private readonly CrmDbContext _db;
        private readonly IAmazonSQS _sqs;
        private readonly string _queueUrl;

        public RegisterCustomerHandler(CrmDbContext db, IAmazonSQS sqs, IConfiguration configuration)
        {
            _db = db;
            _sqs = sqs;
            _queueUrl = configuration["SQS:QueueUrl"];
        }

        public async Task<string> Handle(IRegisterCustomerCommand request, CancellationToken cancellationToken)
        {
            var customer = new Customer { Id = Guid.NewGuid().ToString(), Name = request.Name, Email = request.Email, Status = "Lead" };
            _db.Customers.Add(customer);
            await _db.SaveChangesAsync(cancellationToken);

            var message = JsonConvert.SerializeObject(new CustomerRegisteredEvent(customer.Id, customer.Name, customer.Email));

            await _sqs.SendMessageAsync(new SendMessageRequest
            {
                QueueUrl = _queueUrl,
                MessageBody = message
            }, cancellationToken);

            return customer.Id;
        }
    }

}
