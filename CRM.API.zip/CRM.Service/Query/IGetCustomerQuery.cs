﻿using CRM.Domain.Data;
using MediatR;

namespace CRM.Service.Query
{
    public interface IGetCustomerQuery : IRequest<Customer>
    {
        string Id { get; }
    }
}
