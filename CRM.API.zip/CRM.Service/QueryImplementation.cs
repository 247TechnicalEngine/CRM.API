﻿using CRM.Service.Query;

namespace CRM.Service
{
    public record GetCustomerQuery(string Id) : IGetCustomerQuery;
}
