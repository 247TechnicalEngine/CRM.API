﻿using Amazon.SQS;
using CRM.Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace CRM.Service
{
    public static class ServiceExtensions
    {
        public static void AddCrmServices(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddSingleton<CrmDbContext>(provider =>
            {
                var optionsBuilder = new DbContextOptionsBuilder<CrmDbContext>();

                optionsBuilder.UseNpgsql(configuration.GetConnectionString("DefaultConnection"));

                return new CrmDbContext(optionsBuilder.Options);
            });

            services.AddAWSService<IAmazonSQS>();
        }
    }
}
