﻿using Amazon.SQS;
using CRM.Domain.Data;
using CRM.Domain;
using CRM.Service.Handler;
using CRM.Service;
using Microsoft.EntityFrameworkCore;
using Moq;
using Microsoft.Extensions.Configuration;
using Amazon.SQS.Model;
using CRM.Service.Event;
using Newtonsoft.Json;

namespace CRM.Test
{
    [TestFixture]
    public class AddPricingAgreementHandlerTests
    {
        private CrmDbContext _dbContext;
        private Mock<IAmazonSQS> _mockSqs;
        private Mock<IConfiguration> _mockConfiguration;
        private AddPricingAgreementHandler _handler;
        private string _testQueueUrl = "https://sqs.test.url";

        [SetUp]
        public void Setup()
        {
            // Configure the in-memory database
            var options = new DbContextOptionsBuilder<CrmDbContext>()
                .UseInMemoryDatabase(databaseName: "TestDb")
                .Options;

            _dbContext = new CrmDbContext(options);
            _mockSqs = new Mock<IAmazonSQS>();
            _mockConfiguration = new Mock<IConfiguration>();

            // Mock SQS Queue URL
            _mockConfiguration.Setup(config => config["SQS:QueueUrl"]).Returns(_testQueueUrl);

            _handler = new AddPricingAgreementHandler(_dbContext, _mockSqs.Object, _mockConfiguration.Object);

            // Seed the database with a test customer
            _dbContext.Customers.Add(new Customer { Id = "123", Name = "linh tuan", Email = "linhtuan@example.com", Status = "Lead" });
            _dbContext.SaveChanges();
        }

        [Test]
        public async Task Handle_ShouldAddPricingAgreement_And_SendMessageToSqs()
        {
            // Arrange
            var command = new AddPricingAgreementCommand("123", "P001", 99.99m);

            // Act
            await _handler.Handle(command, CancellationToken.None);

            // Assert: Verify that the pricing agreement was added
            var customer = await _dbContext.Customers.FindAsync("123");
            Assert.IsNotNull(customer);
            Assert.AreEqual(1, customer.PricingAgreements.Count);
            Assert.AreEqual("P001", customer.PricingAgreements[0].ProductId);
            Assert.AreEqual(99.99m, customer.PricingAgreements[0].AgreedPrice);

            // Assert: Verify that an SQS message was sent
            _mockSqs.Verify(sqs => sqs.SendMessageAsync(It.Is<SendMessageRequest>(
                req => req.QueueUrl == _testQueueUrl &&
                       JsonConvert.DeserializeObject<PricingAgreementAddedEvent>(req.MessageBody).CustomerId == "123" &&
                       JsonConvert.DeserializeObject<PricingAgreementAddedEvent>(req.MessageBody).ProductId == "P001" &&
                       JsonConvert.DeserializeObject<PricingAgreementAddedEvent>(req.MessageBody).Price == 99.99m
            ), It.IsAny<CancellationToken>()), Times.Once);
        }

        [Test]
        public void Handle_ShouldThrowException_WhenCustomerNotFound()
        {
            // Arrange
            var command = new AddPricingAgreementCommand("999", "P002", 50.00m); // Non-existent customer

            // Act & Assert: Expect an exception
            var ex = Assert.ThrowsAsync<Exception>(async () => await _handler.Handle(command, CancellationToken.None));
            Assert.AreEqual("Customer not found", ex.Message);
        }

        [TearDown]
        public void TearDown()
        {
            // Clean up the database after each test
            _dbContext.Database.EnsureDeleted();
            _dbContext.Dispose();
        }
    }
}
