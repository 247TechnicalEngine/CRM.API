﻿using CRM.Domain.Data;
using CRM.Domain;
using CRM.Service.Handler;
using CRM.Service;
using Microsoft.EntityFrameworkCore;

namespace CRM.Test
{
    [TestFixture]
    public class GetCustomerHandlerTests
    {
        private CrmDbContext _dbContext;
        private GetCustomerHandler _handler;

        [SetUp]
        public void Setup()
        {
            var options = new DbContextOptionsBuilder<CrmDbContext>()
                .UseInMemoryDatabase("TestDb")
                .Options;

            _dbContext = new CrmDbContext(options);
            _handler = new GetCustomerHandler(_dbContext);

            _dbContext.Customers.Add(new Customer { Id = "123", Name = "linh tuan", Email = "linhtuan@example.com", Status = "Lead" });
            _dbContext.SaveChanges();
        }

        [TearDown]
        public void TearDown()
        {
            // Dispose of the DbContext
            _dbContext.Dispose();
        }

        [Test]
        public async Task Handle_ShouldReturnCustomer()
        {
            var query = new GetCustomerQuery("123");

            var result = await _handler.Handle(query, CancellationToken.None);

            Assert.IsNotNull(result);
            Assert.AreEqual("linh tuan", result.Name);
        }

        [Test]
        public async Task Handle_ShouldReturnNull_WhenCustomerNotFound()
        {
            var query = new GetCustomerQuery("999"); // ID does not exist

            var result = await _handler.Handle(query, CancellationToken.None);

            Assert.IsNull(result);
        }
    }
}
