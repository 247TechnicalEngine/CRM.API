﻿using Amazon.SQS;
using Amazon.SQS.Model;
using CRM.Domain;
using CRM.Service;
using CRM.Service.Handler;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Moq;

namespace CRM.Test
{
    [TestFixture]
    public class RegisterCustomerHandlerTests
    {
        private CrmDbContext _dbContext;
        private Mock<IAmazonSQS> _mockSqs;
        private Mock<IConfiguration> _mockConfiguration;
        private RegisterCustomerHandler _handler;

        [SetUp]
        public void Setup()
        {
            var options = new DbContextOptionsBuilder<CrmDbContext>()
                .UseInMemoryDatabase("TestDb")
                .Options;

            _dbContext = new CrmDbContext(options);
            _mockSqs = new Mock<IAmazonSQS>();
            _mockConfiguration = new Mock<IConfiguration>();
            _mockConfiguration.Setup(config => config["SQS:QueueUrl"]).Returns("https://sqs.url");

            _handler = new RegisterCustomerHandler(_dbContext, _mockSqs.Object, _mockConfiguration.Object);
        }

        [TearDown]
        public void TearDown()
        {
            // Dispose of the DbContext
            _dbContext.Dispose();
        }

        [Test]
        public async Task Handle_ShouldRegisterCustomerAndSendMessage()
        {
            var command = new RegisterCustomerCommand("linh tuan", "linhtuan@example.com");

            var customerId = await _handler.Handle(command, CancellationToken.None);

            var customer = await _dbContext.Customers.FindAsync(customerId);
            Assert.NotNull(customer);
            Assert.AreEqual("linh tuan", customer.Name);
            Assert.AreEqual("linhtuan@example.com", customer.Email);

            _mockSqs.Verify(sqs => sqs.SendMessageAsync(It.IsAny<SendMessageRequest>(), It.IsAny<CancellationToken>()), Times.Once);
        }
    }
}
